VIETNAM WAR 1968 - LINUX DESKTOP INSTALLER
=========================================

QUICK INSTALL (Ubuntu, Debian, Fedora, Arch, Mint, Pop!_OS, SteamOS):
1. Option A (Single-file self-extracting installer):
   chmod +x Vietnam-War-1968-Linux-Installer.sh
   ./Vietnam-War-1968-Linux-Installer.sh

2. Option B (Portable .tar.gz archive):
   tar -xzf Vietnam-War-1968-Linux.tar.gz
   cd Vietnam-War-1968-Linux
   ./install.sh

WHAT IT INSTALLS (No root/sudo needed):
- Offline game bundle: ~/.local/share/VietnamWar1968/app
- Launcher script:     ~/.local/bin/vietnam-war-1968
- Desktop & App Menu:  ~/.local/share/applications/vietnam-war-1968.desktop
- Uninstaller:         ~/.local/share/VietnamWar1968/uninstall.sh
