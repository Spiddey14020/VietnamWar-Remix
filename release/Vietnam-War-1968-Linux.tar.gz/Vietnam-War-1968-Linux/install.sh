#!/usr/bin/env bash
set -euo pipefail

if [ "${1:-}" = "--uninstall" ]; then
  if [ -f "${XDG_DATA_HOME:-$HOME/.local/share}/VietnamWar1968/uninstall.sh" ]; then
    exec bash "${XDG_DATA_HOME:-$HOME/.local/share}/VietnamWar1968/uninstall.sh"
  else
    echo "Vietnam War 1968 is not installed."
    exit 0
  fi
fi

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
INSTALL_DIR="$DATA_HOME/VietnamWar1968"
APPS_DIR="$DATA_HOME/applications"
ICON_PNG_DIR="$DATA_HOME/icons/hicolor/512x512/apps"
ICON_SVG_DIR="$DATA_HOME/icons/hicolor/scalable/apps"
BIN_DIR="$HOME/.local/bin"

DESKTOP_DIR="$HOME/Desktop"
if command -v xdg-user-dir >/dev/null 2>&1; then
  DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
fi

echo "Installing Vietnam War 1968 to $INSTALL_DIR ..."
rm -rf "$INSTALL_DIR/app" "$INSTALL_DIR/bin"
mkdir -p "$INSTALL_DIR/app" "$INSTALL_DIR/bin" "$APPS_DIR" "$ICON_PNG_DIR" "$ICON_SVG_DIR" "$BIN_DIR"

cp -r "$SOURCE_DIR/app/." "$INSTALL_DIR/app/"
cp "$SOURCE_DIR/bin/launch-vietnam-war.sh" "$INSTALL_DIR/bin/launch-vietnam-war.sh"
cp "$SOURCE_DIR/uninstall.sh" "$INSTALL_DIR/uninstall.sh"
chmod +x "$INSTALL_DIR/bin/launch-vietnam-war.sh" "$INSTALL_DIR/uninstall.sh"

ICON_REF="vietnam-war-1968"
if [ -f "$SOURCE_DIR/icons/vietnam-war-1968.png" ]; then
  cp "$SOURCE_DIR/icons/vietnam-war-1968.png" "$ICON_PNG_DIR/vietnam-war-1968.png"
  ICON_REF="$ICON_PNG_DIR/vietnam-war-1968.png"
fi
if [ -f "$SOURCE_DIR/icons/vietnam-war-1968.svg" ]; then
  cp "$SOURCE_DIR/icons/vietnam-war-1968.svg" "$ICON_SVG_DIR/vietnam-war-1968.svg"
fi

ln -sf "$INSTALL_DIR/bin/launch-vietnam-war.sh" "$BIN_DIR/vietnam-war-1968"

DESKTOP_ENTRY="[Desktop Entry]
Version=1.0
Type=Application
Name=Vietnam War 1968
GenericName=Tactical Military FPS
Comment=Open-world 1968 Mekong Valley military simulation FPS
Exec="$INSTALL_DIR/bin/launch-vietnam-war.sh"
Icon=$ICON_REF
Terminal=false
Categories=Game;ActionGame;Shooter;
StartupWMClass=VietnamWar1968
StartupNotify=true
"

UNINSTALL_ENTRY="[Desktop Entry]
Version=1.0
Type=Application
Name=Uninstall Vietnam War 1968
Comment=Remove Vietnam War 1968 from your Linux system
Exec=bash "$INSTALL_DIR/uninstall.sh"
Icon=user-trash
Terminal=true
Categories=Game;
"

printf "%s" "$DESKTOP_ENTRY" > "$APPS_DIR/vietnam-war-1968.desktop"
printf "%s" "$UNINSTALL_ENTRY" > "$APPS_DIR/uninstall-vietnam-war-1968.desktop"
chmod +x "$APPS_DIR/vietnam-war-1968.desktop" "$APPS_DIR/uninstall-vietnam-war-1968.desktop"

if [ -d "$DESKTOP_DIR" ]; then
  printf "%s" "$DESKTOP_ENTRY" > "$DESKTOP_DIR/Vietnam-War-1968.desktop"
  chmod +x "$DESKTOP_DIR/Vietnam-War-1968.desktop"
  if command -v gio >/dev/null 2>&1; then
    gio set "$DESKTOP_DIR/Vietnam-War-1968.desktop" metadata::trusted true 2>/dev/null || true
  fi
fi

if command -v update-desktop-database >/dev/null 2>&1; then
  update-desktop-database "$APPS_DIR" 2>/dev/null || true
fi
if command -v gtk-update-icon-cache >/dev/null 2>&1; then
  gtk-update-icon-cache -f -t "$DATA_HOME/icons/hicolor" 2>/dev/null || true
fi

echo ""
echo "Installation complete!"
echo "  - Applications menu: Vietnam War 1968"
echo "  - Terminal command:  ~/.local/bin/vietnam-war-1968"
echo "  - Uninstall anytime: $INSTALL_DIR/uninstall.sh"
echo ""

if [ "${LAUNCH_AFTER_INSTALL:-0}" = "1" ]; then
  exec "$INSTALL_DIR/bin/launch-vietnam-war.sh"
elif command -v zenity >/dev/null 2>&1 && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
  if zenity --question --title="Vietnam War 1968" --text="Vietnam War 1968 installed successfully!\n\nLaunch the game now?" 2>/dev/null; then
    "$INSTALL_DIR/bin/launch-vietnam-war.sh" &
  fi
fi
