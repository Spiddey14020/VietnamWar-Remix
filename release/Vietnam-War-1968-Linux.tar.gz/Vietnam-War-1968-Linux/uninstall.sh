#!/usr/bin/env bash
set -euo pipefail

DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
INSTALL_DIR="$DATA_HOME/VietnamWar1968"
APPS_DIR="$DATA_HOME/applications"
ICON_PNG="$DATA_HOME/icons/hicolor/512x512/apps/vietnam-war-1968.png"
ICON_SVG="$DATA_HOME/icons/hicolor/scalable/apps/vietnam-war-1968.svg"
BIN_LINK="$HOME/.local/bin/vietnam-war-1968"

DESKTOP_DIR="$HOME/Desktop"
if command -v xdg-user-dir >/dev/null 2>&1; then
  DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
fi

rm -rf "$INSTALL_DIR"
rm -f "$APPS_DIR/vietnam-war-1968.desktop"
rm -f "$APPS_DIR/uninstall-vietnam-war-1968.desktop"
rm -f "$DESKTOP_DIR/Vietnam-War-1968.desktop"
rm -f "$ICON_PNG" "$ICON_SVG" "$BIN_LINK"

if command -v update-desktop-database >/dev/null 2>&1; then
  update-desktop-database "$APPS_DIR" 2>/dev/null || true
fi

echo "Vietnam War 1968 has been uninstalled from $INSTALL_DIR."
if command -v zenity >/dev/null 2>&1 && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
  zenity --info --title="Vietnam War 1968" --text="Vietnam War 1968 has been uninstalled." 2>/dev/null || true
fi
